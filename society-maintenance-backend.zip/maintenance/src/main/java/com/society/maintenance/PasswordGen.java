package com.society.maintenance;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordGen {
    public static void main(String[] args) {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        System.out.println(encoder.encode("@a181994@Csb"));
        
        System.out.println(
        	    java.util.Base64.getEncoder()
        	        .encodeToString(io.jsonwebtoken.security.Keys.secretKeyFor(
        	            io.jsonwebtoken.SignatureAlgorithm.HS256
        	        ).getEncoded())
        	);

    }
}

