package com.society.maintenance.user;

public enum Role {
    SUPER_ADMIN,
    ADMIN,
    OWNER
}
