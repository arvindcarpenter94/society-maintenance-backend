package com.society.maintenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintenanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
